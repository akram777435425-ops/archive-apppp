# libs/share_receiver.py
from kivy.utils import platform
import os

if platform == 'android':
    from jnius import autoclass, cast
    from android import activity, mActivity
    from android.content import Intent

def setup_share_receiver(app):
    if platform != 'android':
        return

    def handle_shared_files(intent):
        if intent.getAction() in [Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE]:
            if intent.getAction() == Intent.ACTION_SEND:
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM)
                if uri:
                    copy_to_temp(uri, app)
            else:
                uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                if uris:
                    for uri in uris:
                        copy_to_temp(uri, app)

    def copy_to_temp(uri, app):
        try:
            context = mActivity
            input_stream = context.getContentResolver().openInputStream(uri)
            # اسم الملف
            display_name = "shared_file"
            # يمكن استخراج الاسم الحقيقي
            temp_dir = os.path.join(app.file_manager.archive_path, 'temp')
            os.makedirs(temp_dir, exist_ok=True)
            temp_path = os.path.join(temp_dir, f"shared_{os.urandom(4).hex()}.tmp")
            with open(temp_path, 'wb') as f:
                f.write(input_stream.read())
            input_stream.close()
            # تمرير الملف للشاشة
            app.shared_file_path = temp_path
            screen = app.root.get_screen('add_transaction')
            screen.shared_file = temp_path
            app.root.current = 'add_transaction'
        except Exception as e:
            print("Share error:", e)

    # ربط intent الأولي
    handle_shared_files(mActivity.getIntent())

    # ربط intents المستقبلية
    def on_new_intent(intent):
        handle_shared_files(intent)
        return True

    activity.bind(on_new_intent=on_new_intent)