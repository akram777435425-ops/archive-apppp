# libs/security.py
import hashlib

class Security:
    def __init__(self, db):
        self.db = db

    def set_pin(self, pin):
        hashed = hashlib.sha256(pin.encode()).hexdigest()
        self.db.set_setting('pin_hash', hashed)

    def verify_pin(self, pin):
        stored = self.db.get_setting('pin_hash')
        if stored is None:
            return True
        return stored == hashlib.sha256(pin.encode()).hexdigest()

    def is_pin_set(self):
        return self.db.get_setting('pin_hash') is not None

    def remove_pin(self):
        self.db.set_setting('pin_hash', None)