# libs/file_manager.py
import os
import shutil

class FileManager:
    def __init__(self, archive_path):
        self.archive_path = archive_path
        os.makedirs(self.archive_path, exist_ok=True)

    def rename_file(self, transaction_type, entity_code, trans_number, year, original_extension):
        type_code = 'و' if transaction_type == 'وارد' else 'ص'
        short_year = str(year)[-2:]
        base_name = f"{type_code}-{entity_code}-{trans_number}-{short_year}"
        # تجنب التكرار
        count = 1
        new_name = f"{base_name}.{original_extension}"
        full_path = os.path.join(self.archive_path, new_name)
        while os.path.exists(full_path):
            new_name = f"{base_name}_{count}.{original_extension}"
            full_path = os.path.join(self.archive_path, new_name)
            count += 1
        return new_name

    def move_file_to_archive(self, source_path, new_name):
        dest = os.path.join(self.archive_path, new_name)
        shutil.move(source_path, dest)
        return dest

    def delete_file(self, filename):
        path = os.path.join(self.archive_path, filename)
        if os.path.exists(path):
            os.remove(path)

    def get_archive_size(self):
        total = 0
        for root, dirs, files in os.walk(self.archive_path):
            for f in files:
                fp = os.path.join(root, f)
                if os.path.isfile(fp):
                    total += os.path.getsize(fp)
        return total

    def change_archive_path(self, new_path):
        old_path = self.archive_path
        if old_path == new_path:
            return
        os.makedirs(new_path, exist_ok=True)
        # نسخ الملفات مع شريط تقدم (يمكن استدعاؤه من الواجهة)
        files = []
        for root, dirs, filenames in os.walk(old_path):
            for f in filenames:
                files.append(os.path.join(root, f))
        total_files = len(files)
        for i, f in enumerate(files):
            dest = os.path.join(new_path, os.path.relpath(f, old_path))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(f, dest)
            # إرسال تقدم (بالمئة)
            if total_files:
                progress = int((i+1)/total_files*100)
                # يمكن استدعاء callback هنا
        self.archive_path = new_path