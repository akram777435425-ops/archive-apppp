# libs/database.py
import sqlite3
import os
from datetime import datetime

DB_NAME = "archive.db"

class Database:
    def __init__(self, db_path=None):
        if db_path is None:
            db_path = DB_NAME
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self.create_tables()
        self._add_defaults()

    def create_tables(self):
        self.cursor.executescript("""
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                parent_id INTEGER DEFAULT NULL,
                FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
            );

            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                phone TEXT,
                email TEXT,
                notes TEXT
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number INTEGER NOT NULL,
                year INTEGER NOT NULL,
                title TEXT NOT NULL,
                date TEXT NOT NULL,
                type TEXT NOT NULL CHECK(type IN ('وارد','صادر')),
                sender TEXT,
                receiver TEXT,
                external_entity TEXT,
                category_id INTEGER,
                priority TEXT CHECK(priority IN ('عادي','هام','سري','سري للغاية')),
                status TEXT CHECK(status IN ('جديدة','قيد التنفيذ','مكتملة','مؤرشفة','مرفوضة')),
                secrecy_level TEXT CHECK(secrecy_level IN ('عادي','هام','سري','سري للغاية')),
                description TEXT,
                keywords TEXT,
                notes TEXT,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
            );

            CREATE TABLE IF NOT EXISTS attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_id INTEGER NOT NULL,
                original_name TEXT,
                stored_name TEXT NOT NULL,
                file_path TEXT NOT NULL,
                added_date TEXT DEFAULT (datetime('now','localtime')),
                FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                details TEXT,
                timestamp TEXT DEFAULT (datetime('now','localtime'))
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        """)
        self.conn.commit()

    def _add_defaults(self):
        # تصنيفات افتراضية
        if self.cursor.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
            cats = ['إداري', 'مالي', 'قانوني', 'تقني']
            for c in cats:
                self.cursor.execute("INSERT INTO categories (name) VALUES (?)", (c,))
            self.conn.commit()

    # ---------- المعاملات ----------
    def add_transaction(self, data):
        sql = """INSERT INTO transactions 
            (number, year, title, date, type, sender, receiver, external_entity,
             category_id, priority, status, secrecy_level, description, keywords, notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
        self.cursor.execute(sql, (
            data['number'], data['year'], data['title'], data['date'],
            data['type'], data.get('sender',''), data.get('receiver',''),
            data.get('external_entity',''), data.get('category_id'),
            data.get('priority','عادي'), data.get('status','جديدة'),
            data.get('secrecy_level','عادي'), data.get('description',''),
            data.get('keywords',''), data.get('notes','')
        ))
        self.conn.commit()
        return self.cursor.lastrowid

    def update_transaction(self, trans_id, data):
        sql = """UPDATE transactions SET
            number=?, year=?, title=?, date=?, type=?, sender=?, receiver=?,
            external_entity=?, category_id=?, priority=?, status=?, secrecy_level=?,
            description=?, keywords=?, notes=?
            WHERE id=?"""
        self.cursor.execute(sql, (
            data['number'], data['year'], data['title'], data['date'],
            data['type'], data.get('sender',''), data.get('receiver',''),
            data.get('external_entity',''), data.get('category_id'),
            data.get('priority','عادي'), data.get('status','جديدة'),
            data.get('secrecy_level','عادي'), data.get('description',''),
            data.get('keywords',''), data.get('notes',''),
            trans_id
        ))
        self.conn.commit()

    def delete_transaction(self, trans_id):
        # المرفقات تُحذف بواسطة CASCADE
        self.cursor.execute("DELETE FROM transactions WHERE id=?", (trans_id,))
        self.conn.commit()

    def get_transaction(self, trans_id):
        self.cursor.execute("SELECT * FROM transactions WHERE id=?", (trans_id,))
        return self.cursor.fetchone()

    def get_all_transactions(self, order_by="date DESC"):
        self.cursor.execute(f"SELECT * FROM transactions ORDER BY {order_by}")
        return self.cursor.fetchall()

    def search_transactions(self, query):
        q = f"%{query}%"
        self.cursor.execute("""SELECT * FROM transactions WHERE
            number LIKE ? OR title LIKE ? OR sender LIKE ? OR receiver LIKE ?
            OR external_entity LIKE ? OR keywords LIKE ? OR notes LIKE ?
            ORDER BY date DESC""",
            (q,q,q,q,q,q,q))
        return self.cursor.fetchall()

    def advanced_search(self, filters):
        sql = "SELECT * FROM transactions WHERE 1=1"
        params = []
        if 'number' in filters:
            sql += " AND number=?"
            params.append(filters['number'])
        if 'year' in filters:
            sql += " AND year=?"
            params.append(filters['year'])
        if 'type' in filters:
            sql += " AND type=?"
            params.append(filters['type'])
        if 'status' in filters:
            sql += " AND status=?"
            params.append(filters['status'])
        if 'category_id' in filters:
            sql += " AND category_id=?"
            params.append(filters['category_id'])
        # إلخ...
        sql += " ORDER BY date DESC"
        self.cursor.execute(sql, params)
        return self.cursor.fetchall()

    # ---------- الإحصائيات ----------
    def count_transactions(self, type=None, status=None, status_in=None):
        sql = "SELECT COUNT(*) FROM transactions WHERE 1=1"
        params = []
        if type:
            sql += " AND type=?"
            params.append(type)
        if status:
            sql += " AND status=?"
            params.append(status)
        if status_in:
            placeholders = ','.join('?' for _ in status_in)
            sql += f" AND status IN ({placeholders})"
            params.extend(status_in)
        self.cursor.execute(sql, params)
        return self.cursor.fetchone()[0]

    def get_monthly_counts(self, months):
        counts = []
        for month in months:
            self.cursor.execute(
                "SELECT COUNT(*) FROM transactions WHERE strftime('%Y-%m', date)=?",
                (month,))
            counts.append(self.cursor.fetchone()[0])
        return counts

    # ---------- المرفقات ----------
    def add_attachment(self, trans_id, original_name, stored_name, file_path):
        self.cursor.execute("INSERT INTO attachments (transaction_id, original_name, stored_name, file_path) VALUES (?,?,?,?)",
                            (trans_id, original_name, stored_name, file_path))
        self.conn.commit()

    def get_attachments(self, trans_id):
        self.cursor.execute("SELECT * FROM attachments WHERE transaction_id=?", (trans_id,))
        return self.cursor.fetchall()

    def delete_attachment(self, att_id):
        self.cursor.execute("DELETE FROM attachments WHERE id=?", (att_id,))
        self.conn.commit()

    # ---------- التصنيفات ----------
    def get_all_categories(self):
        self.cursor.execute("SELECT * FROM categories ORDER BY name")
        return self.cursor.fetchall()

    def get_category_id(self, name):
        self.cursor.execute("SELECT id FROM categories WHERE name=?", (name,))
        row = self.cursor.fetchone()
        return row['id'] if row else None

    def add_category(self, name, parent_id=None):
        self.cursor.execute("INSERT INTO categories (name, parent_id) VALUES (?,?)", (name, parent_id))
        self.conn.commit()

    def delete_category(self, cat_id):
        self.cursor.execute("DELETE FROM categories WHERE id=?", (cat_id,))
        self.conn.commit()

    # ---------- الجهات ----------
    def get_all_entities(self):
        self.cursor.execute("SELECT * FROM entities ORDER BY name")
        return self.cursor.fetchall()

    def get_entity_code(self, name):
        self.cursor.execute("SELECT code FROM entities WHERE name=?", (name,))
        row = self.cursor.fetchone()
        return row['code'] if row else "000"

    def add_entity(self, code, name, phone='', email='', notes=''):
        self.cursor.execute("INSERT INTO entities (code, name, phone, email, notes) VALUES (?,?,?,?,?)",
                            (code, name, phone, email, notes))
        self.conn.commit()

    def delete_entity(self, ent_id):
        self.cursor.execute("DELETE FROM entities WHERE id=?", (ent_id,))
        self.conn.commit()

    # ---------- سجل النشاط ----------
    def log_activity(self, action, details=""):
        self.cursor.execute("INSERT INTO activity_log (action, details) VALUES (?,?)", (action, details))
        self.conn.commit()

    def get_recent_activity(self, limit=10):
        self.cursor.execute("SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT ?", (limit,))
        return self.cursor.fetchall()

    # ---------- الإعدادات ----------
    def get_setting(self, key):
        self.cursor.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = self.cursor.fetchone()
        return row['value'] if row else None

    def set_setting(self, key, value):
        self.cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))
        self.conn.commit()

    def get_all_settings(self):
        self.cursor.execute("SELECT * FROM settings")
        rows = self.cursor.fetchall()
        return {r['key']: r['value'] for r in rows}