# libs/backup.py
import zipfile
import os
import datetime

class BackupManager:
    def __init__(self, db_path, archive_path, backup_dir):
        self.db_path = db_path
        self.archive_path = archive_path
        self.backup_dir = backup_dir
        os.makedirs(self.backup_dir, exist_ok=True)

    def create_backup(self, progress_callback=None):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_{timestamp}.zip"
        full_path = os.path.join(self.backup_dir, filename)
        with zipfile.ZipFile(full_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # قاعدة البيانات
            zipf.write(self.db_path, os.path.basename(self.db_path))
            # مجلد الأرشيف
            if os.path.exists(self.archive_path):
                for root, dirs, files in os.walk(self.archive_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.join('attachments', os.path.relpath(file_path, self.archive_path))
                        zipf.write(file_path, arcname)
        return full_path

    def restore_backup(self, zip_path, progress_callback=None):
        temp_dir = os.path.join(os.path.dirname(self.db_path), 'restore_temp')
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            zipf.extractall(temp_dir)
        # نسخ قاعدة البيانات
        db_file = os.path.basename(self.db_path)
        restored_db = os.path.join(temp_dir, db_file)
        if os.path.exists(restored_db):
            import shutil
            shutil.copy2(restored_db, self.db_path)
        # نسخ المرفقات
        attachments_dir = os.path.join(temp_dir, 'attachments')
        if os.path.exists(attachments_dir):
            import shutil
            if os.path.exists(self.archive_path):
                shutil.rmtree(self.archive_path)
            shutil.copytree(attachments_dir, self.archive_path)
        # حذف المؤقت
        import shutil
        shutil.rmtree(temp_dir)