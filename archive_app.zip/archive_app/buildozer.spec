[app]
title = الأرشيف الإلكتروني
package.name = archiveapp
package.domain = com.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf
version = 1.0
requirements = python3,kivy==2.2.1,pyjnius,openpyxl,reportlab,pillow,plyer,arabic-reshaper,python-bidi
orientation = portrait
fullscreen = 0
android.permissions = READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE
android.arch = armeabi-v7a, arm64-v8a
android.api = 31
android.minapi = 26
android.ndk = 25c
android.sdk = 31
# دعم استقبال الملفات
android.manifest.intent_filters = <?xml version="1.0" encoding="utf-8"?><intent-filter><action android:name="android.intent.action.SEND" /><category android:name="android.intent.category.DEFAULT" /><data android:mimeType="*/*" /></intent-filter>
android.manifest.launch_mode = singleTask