# ui/widgets/charts.py
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, Ellipse, Line
from kivy.uix.label import Label
from math import pi, cos, sin
from kivy.uix.boxlayout import BoxLayout

class PieChart(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.data = {}

    def set_data(self, data):
        self.data = data
        self.canvas.clear()
        total = sum(data.values())
        if total == 0:
            return
        colors = [(0.2,0.6,1,1), (1,0.6,0,1), (0.4,0.8,0.2,1), (1,0.2,0.2,1), (1,0.8,0,1)]
        start_angle = 0
        cx, cy = self.center
        radius = min(self.width, self.height)/2 - 10
        for i, (key, val) in enumerate(data.items()):
            angle = 2*pi * (val/total)
            color = colors[i % len(colors)]
            with self.canvas:
                Color(*color[:3], 0.8)
                # رسم قطاع بمضلع
                points = [cx, cy]
                steps = 50
                for j in range(steps+1):
                    a = start_angle + angle * j / steps
                    points.extend([cx + radius*cos(a), cy + radius*sin(a)])
                Line(points=points, width=2)
            start_angle += angle

class BarChart(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.labels = []
        self.values = []

    def set_data(self, labels, values):
        self.labels = labels
        self.values = values
        self.draw()

    def draw(self):
        self.canvas.clear()
        if not self.values:
            return
        bar_count = len(self.values)
        max_val = max(self.values) if max(self.values) > 0 else 1
        bar_width = self.width / (bar_count * 1.5)
        for i, val in enumerate(self.values):
            x = self.x + i * self.width / bar_count + bar_width * 0.25
            height = (val / max_val) * (self.height - 40)
            y = self.y + 30
            with self.canvas:
                Color(0.2, 0.6, 1, 1)
                Rectangle(pos=(x, y), size=(bar_width, height))
            # تسمية
            lbl = Label(text=str(val), size=(bar_width, 20),
                        pos=(x, y + height), font_size=12, color=(0,0,0,1))
            self.add_widget(lbl)