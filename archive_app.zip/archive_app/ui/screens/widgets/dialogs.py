# ui/widgets/dialogs.py
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button

def confirm_dialog(title, message, callback_yes):
    box = BoxLayout(orientation='vertical', padding=10, spacing=10)
    box.add_widget(Label(text=message))
    btn_box = BoxLayout(size_hint_y=0.3, spacing=10)
    btn_yes = Button(text="نعم")
    btn_no = Button(text="إلغاء")
    popup = Popup(title=title, content=box, size_hint=(0.7, 0.3))
    def on_yes(instance):
        popup.dismiss()
        callback_yes()
    btn_yes.bind(on_release=on_yes)
    btn_no.bind(on_release=popup.dismiss)
    btn_box.add_widget(btn_yes)
    btn_box.add_widget(btn_no)
    box.add_widget(btn_box)
    popup.open()

def progress_popup(title="جاري العمل..."):
    box = BoxLayout(orientation='vertical', padding=10, spacing=10)
    lbl = Label(text=title)
    progress = ProgressBar(max=100)
    box.add_widget(lbl)
    box.add_widget(progress)
    popup = Popup(title="", content=box, size_hint=(0.7, 0.2))
    popup.open()
    return popup, progress