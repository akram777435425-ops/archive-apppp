# ui/widgets/arabic_label.py
from kivy.uix.label import Label
import arabic_reshaper
from bidi.algorithm import get_display

class ArabicLabel(Label):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.font_name = 'Arabic'
        # خاصية لتخزين النص الأصلي قبل إعادة التشكيل (للأيقونات)
        self.raw_text = ''
        self.bind(text=self._reshape)

    def _reshape(self, instance, value):
        if value:
            # لا نعيد تشكيل الأيقونات (نصوص الأيقونة لا تحتاج إعادة تشكيل)
            # لكن إن كان النص عربيًا خالصًا نعيد تشكيله
            if any('\u0600' <= c <= '\u06ff' for c in value):
                reshaped = arabic_reshaper.reshape(value)
                self.text = get_display(reshaped)
            else:
                self.text = value
        else:
            self.text = ""