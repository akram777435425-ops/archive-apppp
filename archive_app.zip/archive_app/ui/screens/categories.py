# ui/screens/categories.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel

class CategoriesScreen(Screen):
    def on_enter(self):
        self.build_ui()

    def build_ui(self):
        self.clear_widgets()
        app = App.get_running_app()
        db = app.db

        root = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # نموذج إضافة
        form = GridLayout(cols=2, size_hint_y=None, height=50, spacing=5)
        form.add_widget(ArabicLabel(text="اسم التصنيف:"))
        self.cat_name = TextInput(multiline=False)
        form.add_widget(self.cat_name)
        root.add_widget(form)

        btn_add = Button(text="إضافة", size_hint_y=None, height=40, on_release=self.add_category)
        root.add_widget(btn_add)

        # قائمة التصنيفات
        self.cat_list = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.cat_list.bind(minimum_height=self.cat_list.setter('height'))
        scroll = ScrollView()
        scroll.add_widget(self.cat_list)
        root.add_widget(scroll)

        self.load_categories()
        self.add_widget(root)

    def load_categories(self):
        self.cat_list.clear_widgets()
        app = App.get_running_app()
        cats = app.db.get_all_categories()
        for cat in cats:
            box = BoxLayout(size_hint_y=None, height=30)
            box.add_widget(ArabicLabel(text=cat['name']))
            btn_del = Button(text="حذف", size_hint_x=0.3)
            btn_del.bind(on_release=lambda x, cid=cat['id']: self.delete_category(cid))
            box.add_widget(btn_del)
            self.cat_list.add_widget(box)

    def add_category(self, instance):
        name = self.cat_name.text.strip()
        if name:
            app = App.get_running_app()
            app.db.add_category(name)
            app.db.log_activity("إضافة تصنيف", name)
            self.cat_name.text = ''
            self.load_categories()

    def delete_category(self, cat_id):
        app = App.get_running_app()
        app.db.delete_category(cat_id)
        app.db.log_activity("حذف تصنيف", str(cat_id))
        self.load_categories()