# ui/screens/reports.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.app import App
from libs.reports import ReportGenerator
from ui.widgets.arabic_label import ArabicLabel
from kivy.uix.popup import Popup

class ReportsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(ArabicLabel(text="التقارير", font_size=20))

        btn_pdf = Button(text="تصدير PDF", on_release=lambda x: self.export('pdf'))
        layout.add_widget(btn_pdf)
        btn_excel = Button(text="تصدير Excel", on_release=lambda x: self.export('excel'))
        layout.add_widget(btn_excel)
        btn_csv = Button(text="تصدير CSV", on_release=lambda x: self.export('csv'))
        layout.add_widget(btn_csv)

        self.add_widget(layout)

    def export(self, fmt):
        app = App.get_running_app()
        path = app.file_manager.archive_path
        filename = f"report_{app.db.get_setting('last_report_id') or '001'}.{fmt}"
        fullpath = f"{path}/{filename}"
        rg = ReportGenerator(app.db)
        try:
            if fmt == 'pdf':
                rg.export_pdf(fullpath)
            elif fmt == 'excel':
                rg.export_excel(fullpath)
            elif fmt == 'csv':
                rg.export_csv(fullpath)
            app.db.log_activity("تصدير تقرير", filename)
            Popup(title="تم", content=ArabicLabel(text=f"تم الحفظ في {fullpath}"), size_hint=(0.7,0.3)).open()
        except Exception as e:
            Popup(title="خطأ", content=ArabicLabel(text=str(e)), size_hint=(0.7,0.3)).open()