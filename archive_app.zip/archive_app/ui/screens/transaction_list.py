# ui/screens/transaction_list.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.recycleview import RecycleView
from kivy.uix.recycleview.views import RecycleDataViewBehavior
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel
from ui.theme import Theme, Card
from kivy.graphics import Color, RoundedRectangle, Line

class TransactionItem(RecycleDataViewBehavior, Card):
    index = None
    def __init__(self, **kwargs):
        super().__init__(orientation='horizontal', padding=10, spacing=10, size_hint_y=None, height=60)
        # أيقونة النوع
        self.type_icon = ArabicLabel(text='', font_name='Icons', font_size=24,
                                     size_hint_x=0.1, color=Theme.PRIMARY)
        self.add_widget(self.type_icon)
        # تفاصيل
        self.details = BoxLayout(orientation='vertical', size_hint_x=0.8)
        self.title_lbl = ArabicLabel(text='', color=Theme.TEXT_PRIMARY, font_size=16,
                                     bold=True, halign='right')
        self.subtitle_lbl = ArabicLabel(text='', color=Theme.TEXT_SECONDARY, font_size=12,
                                        halign='right')
        self.details.add_widget(self.title_lbl)
        self.details.add_widget(self.subtitle_lbl)
        self.add_widget(self.details)

    def refresh_view_attrs(self, rv, index, data):
        self.index = index
        self.title_lbl.text = data['title']
        self.subtitle_lbl.text = data['subtitle']
        # تعيين أيقونة حسب النوع (مثلاً)
        if data.get('type') == 'وارد':
            self.type_icon.text = '[font=Icons]\uf062[/font]'
            self.type_icon.color = Theme.SUCCESS
        else:
            self.type_icon.text = '[font=Icons]\uf063[/font]'
            self.type_icon.color = Theme.ACCENT
        return super().refresh_view_attrs(rv, index, data)

    def on_touch_down(self, touch):
        if super().on_touch_down(touch):
            return True
        if self.collide_point(*touch.pos):
            app = App.get_running_app()
            detail_screen = app.root.get_screen('transaction_detail')
            detail_screen.transaction_id = self.parent.data[self.index]['id']
            app.root.current = 'transaction_detail'
            return True

class TransactionListScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.rv = RecycleView()
        self.rv.viewclass = 'TransactionItem'
        self.rv.data = []
        layout.add_widget(self.rv)

        btn_add = Button(text="[font=Icons]\uf415[/font] إضافة معاملة", markup=True,
                         background_normal='', background_color=Theme.PRIMARY,
                         color=(1,1,1,1), font_size=16, size_hint_y=0.08,
                         on_release=self.go_add)
        layout.add_widget(btn_add)
        self.add_widget(layout)

    def on_enter(self):
        self.load_data()

    def load_data(self, query=None):
        app = App.get_running_app()
        if query:
            data = app.db.search_transactions(query)
        else:
            data = app.db.get_all_transactions()
        rv_data = []
        for row in data:
            rv_data.append({
                'title': f"{row['number']} - {row['title']}",
                'subtitle': f"{row['date']} | {row['status']}",
                'id': row['id'],
                'type': row['type']
            })
        self.rv.data = rv_data

    def go_add(self, instance):
        self.manager.current = 'add_transaction'