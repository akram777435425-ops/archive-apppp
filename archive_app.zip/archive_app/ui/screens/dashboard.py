# ui/screens/dashboard.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.app import App
from datetime import datetime, timedelta
from ui.widgets.charts import PieChart, BarChart
from ui.theme import Theme, Card
from ui.widgets.arabic_label import ArabicLabel
from kivy.graphics import Color, RoundedRectangle

class StatCard(Card):
    def __init__(self, icon, title, value, color=Theme.PRIMARY, **kwargs):
        super().__init__(orientation='horizontal', padding=15, spacing=10, **kwargs)
        self.size_hint_y = None
        self.height = 90
        # أيقونة
        icon_label = ArabicLabel(text=f"[font=Icons]{icon}[/font]", markup=True,
                                 font_name='Icons', font_size=30, color=color,
                                 size_hint_x=0.2)
        self.add_widget(icon_label)
        # النصوص
        text_box = BoxLayout(orientation='vertical', size_hint_x=0.8)
        title_lbl = ArabicLabel(text=title, color=Theme.TEXT_SECONDARY, font_size=14,
                                halign='right', valign='middle')
        title_lbl.bind(size=title_lbl.setter('text_size'))
        val_lbl = ArabicLabel(text=str(value), color=Theme.TEXT_PRIMARY, font_size=22, bold=True,
                              halign='right')
        text_box.add_widget(title_lbl)
        text_box.add_widget(val_lbl)
        self.add_widget(text_box)

class DashboardScreen(Screen):
    def on_enter(self):
        self.clear_widgets()
        self.build_ui()

    def build_ui(self):
        app = App.get_running_app()
        db = app.db

        total = db.count_transactions()
        incoming = db.count_transactions(type='وارد')
        outgoing = db.count_transactions(type='صادر')
        completed = db.count_transactions(status='مكتملة')
        pending = db.count_transactions(status_in=['جديدة','قيد التنفيذ'])
        archive_size = app.file_manager.get_archive_size()

        root = BoxLayout(orientation='vertical', padding=15, spacing=15)

        # التحية
        header = BoxLayout(size_hint_y=0.08, orientation='horizontal')
        header.add_widget(ArabicLabel(text="لوحة التحكم", font_size=26, bold=True,
                                      color=Theme.PRIMARY))
        root.add_widget(header)

        # بطاقات الإحصائيات
        cards_grid = GridLayout(cols=2, spacing=15, size_hint_y=0.4,
                                row_default_height=90, row_force_default=True)
        cards_grid.add_widget(StatCard(icon='\uf133', title="الإجمالي", value=str(total)))
        cards_grid.add_widget(StatCard(icon='\uf062', title="الوارد", value=str(incoming),
                                       color=Theme.SUCCESS))
        cards_grid.add_widget(StatCard(icon='\uf063', title="الصادر", value=str(outgoing),
                                       color=Theme.ACCENT))
        cards_grid.add_widget(StatCard(icon='\uf00c', title="المكتملة", value=str(completed),
                                       color=Theme.SUCCESS))
        cards_grid.add_widget(StatCard(icon='\uf017', title="المفتوحة", value=str(pending),
                                       color=Theme.ERROR))
        cards_grid.add_widget(StatCard(icon='\uf0a0', title="الحجم",
                                       value=self.format_size(archive_size),
                                       color=Theme.PRIMARY_DARK))
        root.add_widget(cards_grid)

        # الرسوم البيانية
        charts_box = BoxLayout(size_hint_y=0.5, spacing=15)
        pie = PieChart()
        pie.set_data({'وارد': incoming, 'صادر': outgoing, 'مكتملة': completed, 'مفتوحة': pending})
        charts_box.add_widget(pie)
        bar = BarChart()
        months = [(datetime.now() - timedelta(days=30*i)).strftime("%Y-%m") for i in range(5, -1, -1)]
        bar.set_data(months, db.get_monthly_counts(months))
        charts_box.add_widget(bar)
        root.add_widget(charts_box)

        # آخر العمليات
        log_label = ArabicLabel(text="آخر العمليات", font_size=18, bold=True, size_hint_y=0.05)
        root.add_widget(log_label)
        scroll = ScrollView(size_hint_y=0.15)
        logs = db.get_recent_activity(10)
        log_text = "\n".join([f"{r['timestamp']}: {r['action']} - {r['details']}" for r in logs])
        log_content = ArabicLabel(text=log_text, size_hint_y=None, halign='right')
        log_content.bind(texture_size=log_content.setter('size'))
        scroll.add_widget(log_content)
        root.add_widget(scroll)

        self.add_widget(root)

    def format_size(self, size_bytes):
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024*1024:
            return f"{size_bytes/1024:.1f} KB"
        else:
            return f"{size_bytes/(1024*1024):.1f} MB"