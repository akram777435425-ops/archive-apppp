# ui/screens/backup_screen.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserIconView
from kivy.app import App
from libs.backup import BackupManager
from ui.widgets.arabic_label import ArabicLabel
from ui.widgets.dialogs import progress_popup

class BackupScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(ArabicLabel(text="النسخ الاحتياطي", font_size=20))
        btn_create = Button(text="إنشاء نسخة احتياطية", on_release=self.create_backup)
        layout.add_widget(btn_create)
        btn_restore = Button(text="استعادة نسخة", on_release=self.restore_backup)
        layout.add_widget(btn_restore)
        self.add_widget(layout)

    def create_backup(self, instance):
        app = App.get_running_app()
        backup_dir = app.db.get_setting('backup_path') or app.archive_path
        bm = BackupManager('archive.db', app.archive_path, backup_dir)
        popup, progress = progress_popup("إنشاء نسخة احتياطية...")
        try:
            path = bm.create_backup()
            popup.dismiss()
            Popup(title="تم", content=ArabicLabel(text=f"تم الحفظ في {path}"), size_hint=(0.7,0.3)).open()
        except Exception as e:
            popup.dismiss()
            Popup(title="خطأ", content=ArabicLabel(text=str(e)), size_hint=(0.7,0.3)).open()

    def restore_backup(self, instance):
        chooser = FileChooserIconView(filters=['*.zip'])
        popup = Popup(title="اختر ملف النسخة", content=chooser, size_hint=(0.9,0.9))
        def select_file(instance):
            if chooser.selection:
                app = App.get_running_app()
                backup_dir = app.db.get_setting('backup_path') or app.archive_path
                bm = BackupManager('archive.db', app.archive_path, backup_dir)
                prog_popup, prog = progress_popup("استعادة...")
                try:
                    bm.restore_backup(chooser.selection[0])
                    prog_popup.dismiss()
                    Popup(title="تم", content=ArabicLabel(text="تمت الاستعادة"), size_hint=(0.7,0.3)).open()
                except Exception as e:
                    prog_popup.dismiss()
                    Popup(title="خطأ", content=ArabicLabel(text=str(e)), size_hint=(0.7,0.3)).open()
                popup.dismiss()
        chooser.bind(on_submit=select_file)
        popup.open()