# ui/screens/entities.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel
from ui.theme import Theme, Card

class EntitiesScreen(Screen):
    def on_enter(self):
        self.build_ui()

    def build_ui(self):
        self.clear_widgets()
        app = App.get_running_app()
        root = BoxLayout(orientation='vertical', padding=15, spacing=15)

        form = Card(orientation='vertical', padding=10, spacing=5, size_hint_y=None, height=200)
        grid = GridLayout(cols=2, spacing=5)
        grid.add_widget(ArabicLabel(text="الكود"))
        self.code = TextInput()
        grid.add_widget(self.code)
        grid.add_widget(ArabicLabel(text="الاسم"))
        self.name = TextInput()
        grid.add_widget(self.name)
        grid.add_widget(ArabicLabel(text="الهاتف"))
        self.phone = TextInput()
        grid.add_widget(self.phone)
        grid.add_widget(ArabicLabel(text="البريد"))
        self.email = TextInput()
        grid.add_widget(self.email)
        grid.add_widget(ArabicLabel(text="ملاحظات"))
        self.notes = TextInput()
        grid.add_widget(self.notes)
        form.add_widget(grid)
        btn_add = Button(text="إضافة جهة", background_color=Theme.PRIMARY,
                         color=(1,1,1,1), size_hint_y=None, height=40, on_release=self.add_entity)
        form.add_widget(btn_add)
        root.add_widget(form)

        # قائمة الجهات
        self.ent_list = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.ent_list.bind(minimum_height=self.ent_list.setter('height'))
        scroll = ScrollView()
        scroll.add_widget(self.ent_list)
        root.add_widget(scroll)

        self.load_entities()
        self.add_widget(root)

    def load_entities(self):
        self.ent_list.clear_widgets()
        app = App.get_running_app()
        for ent in app.db.get_all_entities():
            card = Card(orientation='horizontal', padding=10, spacing=10,
                        size_hint_y=None, height=50)
            card.add_widget(ArabicLabel(text=f"{ent['code']} - {ent['name']}",
                                        color=Theme.TEXT_PRIMARY))
            btn_del = Button(text="[font=Icons]\uf156[/font]", markup=True,
                             font_name='Icons', size_hint_x=0.2,
                             background_normal='', background_color=(0,0,0,0),
                             color=Theme.ERROR)
            btn_del.bind(on_release=lambda x, eid=ent['id']: self.delete_entity(eid))
            card.add_widget(btn_del)
            self.ent_list.add_widget(card)

    def add_entity(self, instance):
        app = App.get_running_app()
        app.db.add_entity(self.code.text, self.name.text, self.phone.text,
                          self.email.text, self.notes.text)
        app.db.log_activity("إضافة جهة", self.name.text)
        self.code.text = self.name.text = self.phone.text = self.email.text = self.notes.text = ''
        self.load_entities()

    def delete_entity(self, eid):
        app = App.get_running_app()
        app.db.delete_entity(eid)
        app.db.log_activity("حذف جهة")
        self.load_entities()