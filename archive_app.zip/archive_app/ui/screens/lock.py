# ui/screens/lock.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel

class LockScreen(Screen):
    def on_enter(self):
        self.build_ui()

    def build_ui(self):
        self.clear_widgets()
        layout = BoxLayout(orientation='vertical', padding=50, spacing=20)
        layout.add_widget(ArabicLabel(text="أدخل رمز PIN", font_size=24))
        self.pin_input = TextInput(password=True, multiline=False, font_size=20, halign='center')
        layout.add_widget(self.pin_input)
        btn = Button(text="دخول", size_hint=(1, 0.2))
        btn.bind(on_release=self.check_pin)
        layout.add_widget(btn)
        self.add_widget(layout)

    def check_pin(self, instance):
        app = App.get_running_app()
        if app.security.verify_pin(self.pin_input.text):
            app.root.current = 'dashboard'
        else:
            popup = Popup(title="خطأ", content=ArabicLabel(text="الرمز غير صحيح"), size_hint=(0.6, 0.3))
            popup.open()