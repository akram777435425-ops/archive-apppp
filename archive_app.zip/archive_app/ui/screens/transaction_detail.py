# ui/screens/transaction_detail.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel

class TransactionDetailScreen(Screen):
    transaction_id = None

    def on_enter(self):
        self.show_detail()

    def show_detail(self):
        self.clear_widgets()
        app = App.get_running_app()
        db = app.db
        trans = db.get_transaction(self.transaction_id)
        if not trans:
            self.add_widget(ArabicLabel(text="لم يتم العثور على المعاملة"))
            return

        layout = BoxLayout(orientation='vertical', padding=10, spacing=5)
        info = f"""
        الرقم: {trans['number']}
        السنة: {trans['year']}
        العنوان: {trans['title']}
        التاريخ: {trans['date']}
        النوع: {trans['type']}
        الحالة: {trans['status']}
        الأولوية: {trans['priority']}
        السرية: {trans['secrecy_level']}
        المرسل: {trans['sender']}
        المستلم: {trans['receiver']}
        الجهة: {trans['external_entity']}
        الوصف: {trans['description']}
        الكلمات المفتاحية: {trans['keywords']}
        الملاحظات: {trans['notes']}
        """
        layout.add_widget(ArabicLabel(text=info, size_hint_y=0.8))

        # المرفقات
        atts = db.get_attachments(trans['id'])
        if atts:
            layout.add_widget(ArabicLabel(text="المرفقات:"))
            for att in atts:
                layout.add_widget(ArabicLabel(text=f"- {att['original_name']} ({att['stored_name']})"))

        btns = BoxLayout(size_hint_y=0.1, spacing=10)
        btn_back = Button(text="رجوع", on_release=lambda x: setattr(self.manager, 'current', 'transactions'))
        btns.add_widget(btn_back)
        layout.add_widget(btns)
        self.add_widget(layout)