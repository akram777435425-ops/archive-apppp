# ui/screens/transaction_add.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.app import App
from datetime import datetime
from ui.widgets.arabic_label import ArabicLabel
from ui.theme import Theme, Card
import os

class CollapsibleSection(BoxLayout):
    def __init__(self, title, **kwargs):
        super().__init__(orientation='vertical', size_hint_y=None, **kwargs)
        self.bind(minimum_height=self.setter('height'))
        self.title_btn = Button(text=title, size_hint_y=None, height=40,
                                background_normal='', background_color=Theme.PRIMARY_LIGHT,
                                color=Theme.PRIMARY, bold=True, font_size=16)
        self.title_btn.bind(on_release=self.toggle)
        self.content = BoxLayout(orientation='vertical', size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter('height'))
        self.add_widget(self.title_btn)
        self.add_widget(self.content)
        self.is_open = True

    def toggle(self, instance):
        if self.is_open:
            self.remove_widget(self.content)
            self.is_open = False
        else:
            self.add_widget(self.content)
            self.is_open = True

class TransactionAddScreen(Screen):
    shared_file = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.attachment_paths = []

    def on_enter(self):
        self.build_form()

    def build_form(self):
        self.clear_widgets()
        app = App.get_running_app()
        db = app.db

        scroll = ScrollView()
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=15, size_hint_y=None)
        main_layout.bind(minimum_height=main_layout.setter('height'))

        # قسم البيانات الأساسية
        basic = CollapsibleSection(title="البيانات الأساسية")
        basic_grid = GridLayout(cols=2, spacing=10, size_hint_y=None)
        basic_grid.bind(minimum_height=basic_grid.setter('height'))
        fields = [
            ("رقم المعاملة *", TextInput(multiline=False)),
            ("السنة *", TextInput(text=str(datetime.now().year), multiline=False)),
            ("العنوان *", TextInput(multiline=False)),
            ("التاريخ", TextInput(text=datetime.now().strftime("%Y-%m-%d"), multiline=False)),
        ]
        self.inputs = {}
        for label_text, widget in fields:
            basic_grid.add_widget(ArabicLabel(text=label_text, color=Theme.TEXT_SECONDARY))
            basic_grid.add_widget(widget)
            self.inputs[label_text] = widget
        basic.content.add_widget(basic_grid)
        main_layout.add_widget(basic)

        # قسم التصنيف والجهات
        class_section = CollapsibleSection(title="التصنيف والجهات")
        class_grid = GridLayout(cols=2, spacing=10, size_hint_y=None)
        class_grid.bind(minimum_height=class_grid.setter('height'))

        class_grid.add_widget(ArabicLabel(text="النوع *"))
        self.type = Spinner(text='وارد', values=('وارد','صادر'))
        class_grid.add_widget(self.type)

        class_grid.add_widget(ArabicLabel(text="الجهة الخارجية"))
        entities = [e['name'] for e in db.get_all_entities()]
        self.external_entity = Spinner(text=entities[0] if entities else '', values=entities)
        class_grid.add_widget(self.external_entity)

        class_grid.add_widget(ArabicLabel(text="التصنيف"))
        cats = [c['name'] for c in db.get_all_categories()]
        self.category = Spinner(text=cats[0] if cats else '', values=cats)
        class_grid.add_widget(self.category)

        class_grid.add_widget(ArabicLabel(text="الأولوية"))
        self.priority = Spinner(text='عادي', values=['عادي','هام','سري','سري للغاية'])
        class_grid.add_widget(self.priority)

        class_grid.add_widget(ArabicLabel(text="الحالة"))
        self.status = Spinner(text='جديدة', values=['جديدة','قيد التنفيذ','مكتملة','مؤرشفة','مرفوضة'])
        class_grid.add_widget(self.status)

        class_grid.add_widget(ArabicLabel(text="مستوى السرية"))
        self.secrecy = Spinner(text='عادي', values=['عادي','هام','سري','سري للغاية'])
        class_grid.add_widget(self.secrecy)

        class_section.content.add_widget(class_grid)
        main_layout.add_widget(class_section)

        # قسم جهات الاتصال
        contact_section = CollapsibleSection(title="جهات الاتصال")
        contact_grid = GridLayout(cols=2, spacing=10, size_hint_y=None)
        contact_grid.bind(minimum_height=contact_grid.setter('height'))
        contact_grid.add_widget(ArabicLabel(text="المرسل"))
        self.sender = TextInput(multiline=False)
        contact_grid.add_widget(self.sender)
        contact_grid.add_widget(ArabicLabel(text="المستلم"))
        self.receiver = TextInput(multiline=False)
        contact_grid.add_widget(self.receiver)
        contact_section.content.add_widget(contact_grid)
        main_layout.add_widget(contact_section)

        # قسم التفاصيل
        detail_section = CollapsibleSection(title="تفاصيل أخرى")
        detail_grid = GridLayout(cols=1, spacing=10, size_hint_y=None)
        detail_grid.bind(minimum_height=detail_grid.setter('height'))
        detail_grid.add_widget(ArabicLabel(text="الوصف"))
        self.desc = TextInput(multiline=True, size_hint_y=None, height=80)
        detail_grid.add_widget(self.desc)
        detail_grid.add_widget(ArabicLabel(text="الكلمات المفتاحية"))
        self.keywords = TextInput(multiline=False)
        detail_grid.add_widget(self.keywords)
        detail_grid.add_widget(ArabicLabel(text="الملاحظات"))
        self.notes = TextInput(multiline=False)
        detail_grid.add_widget(self.notes)
        detail_section.content.add_widget(detail_grid)
        main_layout.add_widget(detail_section)

        # قسم المرفقات
        attach_section = CollapsibleSection(title="المرفقات")
        attach_box = BoxLayout(orientation='vertical', spacing=5, size_hint_y=None)
        attach_box.bind(minimum_height=attach_box.setter('height'))
        self.attach_list = BoxLayout(orientation='vertical', size_hint_y=None, spacing=2)
        self.attach_list.bind(minimum_height=self.attach_list.setter('height'))
        btn_add_attach = Button(text="[font=Icons]\uf415[/font] إضافة مرفق", markup=True,
                                background_normal='', background_color=Theme.PRIMARY_LIGHT,
                                color=Theme.PRIMARY, size_hint_y=None, height=40)
        btn_add_attach.bind(on_release=self.add_attachment)
        attach_box.add_widget(self.attach_list)
        attach_box.add_widget(btn_add_attach)
        attach_section.content.add_widget(attach_box)
        main_layout.add_widget(attach_section)

        # أزرار الحفظ والإلغاء
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        save_btn = Button(text="حفظ", background_color=Theme.PRIMARY, color=(1,1,1,1))
        save_btn.bind(on_release=self.save_transaction)
        cancel_btn = Button(text="إلغاء", background_color=Theme.TEXT_SECONDARY, color=(1,1,1,1))
        cancel_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'transactions'))
        btn_box.add_widget(save_btn)
        btn_box.add_widget(cancel_btn)
        main_layout.add_widget(btn_box)

        scroll.add_widget(main_layout)
        self.add_widget(scroll)

    def add_attachment(self, instance):
        chooser = FileChooserIconView()
        popup = Popup(title="اختر ملف", content=chooser, size_hint=(0.9,0.9))
        def select(instance):
            if chooser.selection:
                path = chooser.selection[0]
                self.attachment_paths.append(path)
                self.attach_list.add_widget(ArabicLabel(text=os.path.basename(path), size_hint_y=None, height=25))
                popup.dismiss()
        chooser.bind(on_submit=select)
        popup.open()

    def save_transaction(self, instance):
        # استخراج القيم من الحقول
        data = {
            'number': int(self.inputs["رقم المعاملة *"].text),
            'year': int(self.inputs["السنة *"].text),
            'title': self.inputs["العنوان *"].text,
            'date': self.inputs["التاريخ"].text,
            'type': self.type.text,
            'sender': self.sender.text,
            'receiver': self.receiver.text,
            'external_entity': self.external_entity.text,
            'category_id': App.get_running_app().db.get_category_id(self.category.text),
            'priority': self.priority.text,
            'status': self.status.text,
            'secrecy_level': self.secrecy.text,
            'description': self.desc.text,
            'keywords': self.keywords.text,
            'notes': self.notes.text
        }
        app = App.get_running_app()
        trans_id = app.db.add_transaction(data)
        entity_code = app.db.get_entity_code(self.external_entity.text) if self.external_entity.text else "000"
        fm = app.file_manager

        for path in self.attachment_paths:
            ext = os.path.splitext(path)[1][1:]
            new_name = fm.rename_file(data['type'], entity_code, data['number'], data['year'], ext)
            dest = fm.move_file_to_archive(path, new_name)
            app.db.add_attachment(trans_id, os.path.basename(path), new_name, dest)

        if self.shared_file:
            ext = os.path.splitext(self.shared_file)[1][1:]
            new_name = fm.rename_file(data['type'], entity_code, data['number'], data['year'], ext)
            dest = fm.move_file_to_archive(self.shared_file, new_name)
            app.db.add_attachment(trans_id, os.path.basename(self.shared_file), new_name, dest)
            self.shared_file = None

        app.db.log_activity("إضافة معاملة", f"رقم {data['number']}")
        self.manager.current = 'transactions'