# ui/screens/settings.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel
from ui.theme import Theme, Card
from ui.widgets.dialogs import progress_popup

class SettingsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=15, spacing=15)
        layout.add_widget(ArabicLabel(text="[font=Icons]\uf493[/font] الإعدادات", font_size=24,
                                      bold=True, color=Theme.PRIMARY, markup=True))
        content = GridLayout(cols=2, spacing=10, size_hint_y=0.4)
        # مسار الأرشيف
        content.add_widget(ArabicLabel(text="مسار الأرشيف", color=Theme.TEXT_SECONDARY))
        self.archive_path = TextInput(text=App.get_running_app().archive_path)
        content.add_widget(self.archive_path)
        # مسار النسخ الاحتياطي
        content.add_widget(ArabicLabel(text="مسار النسخ الاحتياطي"))
        self.backup_path = TextInput(text=App.get_running_app().db.get_setting('backup_path') or '')
        content.add_widget(self.backup_path)
        # الثيم
        content.add_widget(ArabicLabel(text="المظهر"))
        self.theme = Spinner(text='فاتح', values=['فاتح','داكن'])
        content.add_widget(self.theme)
        layout.add_widget(content)

        btn_save = Button(text="حفظ الإعدادات", background_color=Theme.PRIMARY,
                          color=(1,1,1,1), size_hint_y=0.08, on_release=self.save)
        layout.add_widget(btn_save)
        self.add_widget(layout)

    def save(self, instance):
        app = App.get_running_app()
        # تغيير مسار الأرشيف
        new_archive = self.archive_path.text.strip()
        if new_archive and new_archive != app.archive_path:
            popup, prog = progress_popup("نقل الملفات...")
            try:
                app.file_manager.change_archive_path(new_archive)
                app.db.set_setting('archive_path', new_archive)
                app.archive_path = new_archive
                popup.dismiss()
            except Exception as e:
                popup.dismiss()
        app.db.set_setting('backup_path', self.backup_path.text.strip())
        if self.theme.text == 'داكن':
            Theme.set_dark()
        else:
            Theme.set_light()
        app.db.log_activity("تحديث الإعدادات")