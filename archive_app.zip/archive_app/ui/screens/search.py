# ui/screens/search.py
from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.recycleview import RecycleView
from kivy.app import App
from ui.widgets.arabic_label import ArabicLabel
from ui.screens.transaction_list import SelectableLabel

class SearchScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(ArabicLabel(text="بحث متقدم", font_size=20))
        self.search_input = TextInput(multiline=False, hint_text="أدخل كلمة البحث")
        layout.add_widget(self.search_input)

        btn = Button(text="بحث", size_hint_y=0.1, on_release=self.do_search)
        layout.add_widget(btn)

        self.rv = RecycleView()
        self.rv.viewclass = 'SelectableLabel'
        self.rv.data = []
        layout.add_widget(self.rv)

        self.add_widget(layout)

    def do_search(self, instance):
        app = App.get_running_app()
        query = self.search_input.text
        if query:
            results = app.db.search_transactions(query)
            self.rv.data = [{'text': f"{r['number']} - {r['title']}", 'id': r['id']} for r in results]