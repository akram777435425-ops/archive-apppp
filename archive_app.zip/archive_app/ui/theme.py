# ui/theme.py
from kivy.utils import get_color_from_hex
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.boxlayout import BoxLayout

class Theme:
    # لوحة الألوان العصرية (مستوحاة من Material You)
    PRIMARY = get_color_from_hex("#1E6EF0")        # أزرق عصري
    PRIMARY_DARK = get_color_from_hex("#1557C0")
    PRIMARY_LIGHT = get_color_from_hex("#E8F0FE")
    ACCENT = get_color_from_hex("#FF6D00")         # برتقالي للإبراز
    BACKGROUND = get_color_from_hex("#F8F9FA")     # خلفية فاتحة
    SURFACE = get_color_from_hex("#FFFFFF")        # سطح البطاقات
    TEXT_PRIMARY = get_color_from_hex("#202124")
    TEXT_SECONDARY = get_color_from_hex("#5F6368")
    ERROR = get_color_from_hex("#D93025")
    SUCCESS = get_color_from_hex("#188038")
    SHADOW = get_color_from_hex("#000000", 0.08)   # لون ظل

    # متغيرات للثيم الداكن
    _is_dark = False

    @classmethod
    def set_light(cls):
        cls.PRIMARY = get_color_from_hex("#1E6EF0")
        cls.BACKGROUND = get_color_from_hex("#F8F9FA")
        cls.SURFACE = get_color_from_hex("#FFFFFF")
        cls.TEXT_PRIMARY = get_color_from_hex("#202124")
        cls.TEXT_SECONDARY = get_color_from_hex("#5F6368")
        cls.SHADOW = get_color_from_hex("#000000", 0.08)
        cls._is_dark = False

    @classmethod
    def set_dark(cls):
        cls.PRIMARY = get_color_from_hex("#8AB4F8")
        cls.BACKGROUND = get_color_from_hex("#121212")
        cls.SURFACE = get_color_from_hex("#1E1E1E")
        cls.TEXT_PRIMARY = get_color_from_hex("#E8EAED")
        cls.TEXT_SECONDARY = get_color_from_hex("#9AA0A6")
        cls.SHADOW = get_color_from_hex("#FFFFFF", 0.05)
        cls._is_dark = True

# مكون واجهة "بطاقة" بظل وزوايا مستديرة
class Card(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(rgba=Theme.SHADOW)
            # ظل خارجي بسيط: رسم مستطيل دائري بإزاحة
            self.shadow_rect = RoundedRectangle(
                pos=(self.x + 4, self.y - 4), size=self.size, radius=[12])
            Color(rgba=Theme.SURFACE)
            self.bg_rect = RoundedRectangle(
                pos=self.pos, size=self.size, radius=[12])
        self.bind(pos=self.update_graphics, size=self.update_graphics)

    def update_graphics(self, *args):
        self.shadow_rect.pos = (self.x + 3, self.y - 3)
        self.shadow_rect.size = self.size
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size