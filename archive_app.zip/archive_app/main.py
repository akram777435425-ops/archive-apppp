# main.py
import os
os.environ['KIVY_TEXT'] = 'pil'

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.core.window import Window
from kivy.utils import platform
from kivy.core.text import LabelBase
from plyer import storagepath

from libs.database import Database
from libs.file_manager import FileManager
from libs.security import Security

from ui.screens.dashboard import DashboardScreen
from ui.screens.transaction_list import TransactionListScreen
from ui.screens.transaction_add import TransactionAddScreen
from ui.screens.transaction_detail import TransactionDetailScreen
from ui.screens.categories import CategoriesScreen
from ui.screens.entities import EntitiesScreen
from ui.screens.backup_screen import BackupScreen
from ui.screens.reports import ReportsScreen
from ui.screens.settings import SettingsScreen
from ui.screens.search import SearchScreen
from ui.screens.lock import LockScreen
from ui.theme import Theme

class MainScreen(BoxLayout):
    def __init__(self, sm, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.sm = sm
        self.build_nav()

    def build_nav(self):
        nav = BoxLayout(size_hint_y=0.08, padding=[10,0,10,5], spacing=10,
                        canvas.before=[
                            Color(rgba=Theme.SURFACE),
                            RoundedRectangle(radius=[0,0,20,20])
                        ])
        # أيقونات اليونيكود (Material Design Icons)
        icons = {
            'dashboard': '\uf015',   # منزل
            'transactions': '\uf04f', # ملفات
            'add_transaction': '\uf415', # إضافة
            'search': '\uf349',      # بحث
            'settings': '\uf493'     # إعدادات
        }
        targets = {
            'dashboard': 'dashboard',
            'transactions': 'transactions',
            'add_transaction': 'add_transaction',
            'search': 'search',
            'settings': 'settings'
        }
        for key, icon in icons.items():
            btn = Button(text=f"[font=Icons]{icon}[/font]", markup=True,
                         font_name='Icons', font_size=22,
                         background_normal='', background_color=(0,0,0,0),
                         color=(0.3,0.3,0.3,1) if key != 'dashboard' else Theme.PRIMARY)
            btn.bind(on_release=lambda x, target=targets[key]: self.sm.set_current(target))
            nav.add_widget(btn)
        self.add_widget(self.sm)
        self.add_widget(nav)

class ArchiveApp(App):
    def build(self):
        self.title = "الأرشيف الإلكتروني"
        # تسجيل الخطوط
        LabelBase.register(name='Arabic', fn_regular='assets/fonts/Cairo-Regular.ttf')
        LabelBase.register(name='Icons', fn_regular='assets/fonts/materialdesignicons-webfont.ttf')
        Window.softinput_mode = "below_target"

        # قاعدة البيانات ومدير الملفات
        self.db = Database()
        self.archive_path = self.db.get_setting('archive_path') or os.path.join(storagepath.get_documents_dir(), 'ArchiveFiles')
        os.makedirs(self.archive_path, exist_ok=True)
        self.file_manager = FileManager(self.archive_path)
        self.security = Security(self.db)

        # مدير الشاشات
        sm = ScreenManager(transition=FadeTransition())
        sm.add_widget(DashboardScreen(name='dashboard'))
        sm.add_widget(TransactionListScreen(name='transactions'))
        sm.add_widget(TransactionAddScreen(name='add_transaction'))
        sm.add_widget(TransactionDetailScreen(name='transaction_detail'))
        sm.add_widget(CategoriesScreen(name='categories'))
        sm.add_widget(EntitiesScreen(name='entities'))
        sm.add_widget(BackupScreen(name='backup'))
        sm.add_widget(ReportsScreen(name='reports'))
        sm.add_widget(SettingsScreen(name='settings'))
        sm.add_widget(SearchScreen(name='search'))
        sm.add_widget(LockScreen(name='lock'))

        # شريط تنقل رئيسي
        main_layout = MainScreen(sm)

        # استقبال المشاركات (اندرويد)
        if platform == 'android':
            from libs.share_receiver import setup_share_receiver
            setup_share_receiver(self)

        # التحقق من القفل
        if self.security.is_pin_set():
            sm.current = 'lock'
        else:
            sm.current = 'dashboard'

        return main_layout

if __name__ == '__main__':
    ArchiveApp().run()